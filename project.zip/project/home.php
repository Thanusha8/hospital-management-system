<?php

include 'config.php';

session_start();

$user_id = $_SESSION['user_id'] ?? null;



if(isset($_POST['add_to_queue'])){


if(!isset($user_id)){
   header('location:login.php');
}

   $service_name = $_POST['service_name'];
   $service_description = $_POST['service_description'];
   $service_price = $_POST['service_price'];
   $service_image = $_POST['service_image'];
   

   $check_queue_numbers = mysqli_query($conn, "SELECT * FROM `queue` WHERE name = '$service_name' AND user_id = '$user_id'") or die('query failed');

   if(mysqli_num_rows($check_queue_numbers) > 0){
      $message[] = 'already added to queue!';
   }else{
      mysqli_query($conn, "INSERT INTO `queue`(user_id, name,description, price, image) VALUES('$user_id', '$service_name','$service_description', '$service_price','$service_image')") or die('query failed');
      $message[] = 'service added to queue!';
   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>home</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'header.php'; ?>

<section class="home">

   <div class="content">
      <h3>Trusted doctors, trusted care</h3>
      <p>Our skilled doctors and staff guarantee you receive the best care.</p>
      <a href="about.php" class="white-btn">Find a Doctor</a>
   </div>

</section>

<section class="services">

   <h1 class="title">Our Services</h1>

   <div class="box-container">

      <?php  
         $select_services = mysqli_query($conn, "SELECT * FROM `services` LIMIT 6") or die('query failed');
         if(mysqli_num_rows($select_services) > 0){
            while($fetch_services = mysqli_fetch_assoc($select_services)){
      ?>
     <form action="" method="post" class="box">
      <img class="image" src="uploaded_img/<?php echo $fetch_services['image']; ?>" alt="">
      <div class="name"><?php echo $fetch_services['name']; ?></div>
      <div class="description"><?php echo $fetch_services['description']; ?></div>
      <div class="price">Rs <?php echo $fetch_services['price']; ?>/-</div>


      
      <input type="hidden" name="service_name" value="<?php echo $fetch_services['name']; ?>">
      <input type="hidden" name="service_description" value="<?php echo $fetch_services['description']; ?>">
      <input type="hidden" name="service_price" value="<?php echo $fetch_services['price']; ?>">
      <input type="hidden" name="service_image" value="<?php echo $fetch_services['image']; ?>">
      <input type="submit" value="add to queue" name="add_to_queue" class="btn">
     </form>
      <?php
         }
      }else{
         echo '<p class="empty">no services added yet!</p>';
      }
      ?>
   </div>

   <div class="load-more" style="margin-top: 2rem; text-align:center">
      <a href="services.php" class="option-btn">load more</a>
   </div>

</section>

<section class="about">

   <div class="flex">

      <div class="image">
         <img src="images/about-home-img.jpg" alt="">
      </div>

      <div class="content">
         <h3>Our Trusted Team</h3>
         <p>Great care starts with great people. At Care Compass Hospitals, our doctors and staff are here to make sure you get the best treatment with kindness and expertise. Want to know more about the team looking after you? </p>
         <a href="about.php" class="btn">View Medical Staff </a>
      </div>

   </div>

</section>

<section class="home-contact">

   <div class="content">
      <h3>Get in touch with us today</h3>
      <p>We're always ready to assist you.</p>
      <a href="contact.php" class="white-btn">Send a Message</a>
   </div>

</section>





<?php include 'footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>