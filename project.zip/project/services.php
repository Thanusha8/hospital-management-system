<?php

include 'config.php';      // database configuration file

session_start();

$user_id = $_SESSION['user_id'];     // taking the  user ID from session


//Redirecting user to login page if not logged in

if(!isset($user_id)){
   header('location:login.php');
}


// Handling 'Add to queue' functionality

if(isset($_POST['add_to_queue'])){

   $service_name = $_POST['service_name'];     // Getting service name from form DB
   $service_description = $_POST['service_description'];
   $service_price = $_POST['service_price'];     // Getting service price from form DB
   $service_image = $_POST['service_image'];        // Getting service image from form DB
   


   // Checking if service is already in the queue (using queue talble in DB)     *******

   $check_queue_numbers = mysqli_query($conn, "SELECT * FROM `queue` WHERE name = '$service_name' AND user_id = '$user_id'") or die('query failed');

   if(mysqli_num_rows($check_queue_numbers) > 0){
      $message[] = 'already added to queue!';          // service already exists in queue
   }else{
      mysqli_query($conn, "INSERT INTO `queue`(user_id, name,description, price, image) VALUES('$user_id', '$service_name','$service_description', '$service_price', '$service_image')") or die('query failed');
      $message[] = 'service added to queue!';      // Inserting service into queue table 
   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Services</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'header.php'; ?>

<div class="heading">
   <h3>Services</h3>
   <p> <a href="home.php">home</a> / Services </p>
</div>

<section class="services">

   <h1 class="title">Our Services</h1>

   <div class="box-container">
      
      <?php   //Fetching all services from the DB

         $select_services = mysqli_query($conn, "SELECT * FROM `services`") or die('query failed');
         if(mysqli_num_rows($select_services) > 0){
            while($fetch_services = mysqli_fetch_assoc($select_services)){
      ?>
     <form action="" method="post" class="box">
      <img class="image" src="uploaded_img/<?php echo $fetch_services['image']; ?>" alt="">  <!-- Displaying service image -->
      <div class="name"><?php echo $fetch_services['name']; ?></div>                         <!-- Displaying service name -->
      <div class="description"><?php echo $fetch_services['description']; ?></div>  <!-- Displaying service description -->

      <div class="price">Rs <?php echo $fetch_services['price']; ?>/-</div>                    <!-- Displaying service price -->
      
      <input type="hidden" name="service_name" value="<?php echo $fetch_services['name']; ?>">
      <input type="hidden" name="service_description" value="<?php echo $fetch_services['description']; ?>">
      <input type="hidden" name="service_price" value="<?php echo $fetch_services['price']; ?>">
      <input type="hidden" name="service_image" value="<?php echo $fetch_services['image']; ?>">
      <input type="submit" value="add to queue" name="add_to_queue" class="btn">                  <!-- Add to queue button -->
     </form>
      <?php
         }
      }else{
         echo '<p class="empty">no services added yet!</p>';
      }
      ?>
   </div>

</section>








<?php include 'footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>