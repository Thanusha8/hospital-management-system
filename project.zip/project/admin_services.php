<?php

include 'config.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:login.php');
};


// Handle the form submission for adding a new service
if(isset($_POST['add_service'])){


   // Secure the service name input to prevent SQL injection
   $name = mysqli_real_escape_string($conn, $_POST['name']);
   $price = $_POST['price'];    // Get the service price
   $description = mysqli_real_escape_string($conn, $_POST['description']);  // Secure the description input

   $image = $_FILES['image']['name'];    // Get the image name
   $image_size = $_FILES['image']['size'];   // Get the image size
   $image_tmp_name = $_FILES['image']['tmp_name'];   // Get the temporary file name
   $image_folder = 'uploaded_img/'.$image;    // Define the folder path for the image



   // Check if the service name already exists in the database
   $select_service_name = mysqli_query($conn, "SELECT name FROM `services` WHERE name = '$name'") or die('query failed');
 
   // If the service already exists, show a message
   if(mysqli_num_rows($select_service_name) > 0){
      $message[] = 'service name already added';
   }else{
      // Insert the new service into the database
      $add_service_query = mysqli_query($conn, "INSERT INTO `services`(name,description, price, image) VALUES('$name','$description', '$price', '$image')") or die('query failed');

      if($add_service_query){
         if($image_size > 2000000){   // Check if the image size is greater than 2MB
            $message[] = 'image size is too large';
         }else{

            // Move the uploaded image to the specified folder
            move_uploaded_file($image_tmp_name, $image_folder);
            $message[] = 'service added successfully!';
         }
      }else{
         $message[] = 'service could not be added!';
      }
   }
}

// Handle service deletion
if(isset($_GET['delete'])){
   $delete_id = $_GET['delete'];  // Get the service ID to delete

    // Get the image name of the service to delete
   $delete_image_query = mysqli_query($conn, "SELECT image FROM `services` WHERE id = '$delete_id'") or die('query failed');
   $fetch_delete_image = mysqli_fetch_assoc($delete_image_query);
   
   // Delete the service image from the folder
   unlink('uploaded_img/'.$fetch_delete_image['image']);
   
   // Delete the service from the database
   mysqli_query($conn, "DELETE FROM `services` WHERE id = '$delete_id'") or die('query failed');
   
   // Redirect to the admin services page
   header('location:admin_services.php');
}


// Handle service update
if(isset($_POST['update_service'])){

   $update_p_id = $_POST['update_p_id'];  // Get the service ID
   $update_name = $_POST['update_name'];  // Get the updated name
   $update_description = mysqli_real_escape_string($conn, $_POST['update_description']);  // Get the updated description

   $update_price = $_POST['update_price'];  // Get the updated price


   // Update the service name and price in the database
   mysqli_query($conn, "UPDATE `services` SET name = '$update_name',description = '$update_description', price = '$update_price' WHERE id = '$update_p_id'") or die('query failed');

   $update_image = $_FILES['update_image']['name'];    // Get the new image name
   $update_image_tmp_name = $_FILES['update_image']['tmp_name'];  // Get the temporary image name
   $update_image_size = $_FILES['update_image']['size'];   // Get the image size
   $update_folder = 'uploaded_img/'.$update_image;       // Define the image folder
   $update_old_image = $_POST['update_old_image'];       // Get the old image name

   if(!empty($update_image)){
      if($update_image_size > 2000000){
         $message[] = 'image file size is too large';
      }else{

         // Update the image in the database
         mysqli_query($conn, "UPDATE `services` SET image = '$update_image' WHERE id = '$update_p_id'") or die('query failed');
         
         // Move the new image to the folder
         move_uploaded_file($update_image_tmp_name, $update_folder);
         
         // Delete the old image
         unlink('uploaded_img/'.$update_old_image);
      }
   }

   // Redirect to the admin service page
   header('location:admin_services.php');

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>services</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="css/admin_style.css">

</head>
<body>
   
<?php include 'admin_header.php'; ?>

<!-- service CRUD section starts  -->

<section class="add-services">

   <h1 class="title">Hospital services</h1>

   <form action="" method="post" enctype="multipart/form-data">  <!-- Form for adding services, allowing file uploads -->
      <h3>add service</h3>
      <input type="text" name="name" class="box" placeholder="Enter service name" required>    <!-- service name input field -->
      <input type="text" name="description" class="box" placeholder="Enter service description" required> <!-- New input field -->
      <input type="number" min="0" name="price" class="box" placeholder="Enter service price" required>   <!-- service price input field -->
      <input type="file" name="image" accept="image/jpg, image/jpeg, image/png" class="box" required>     <!-- File input for service image -->
      <input type="submit" value="add service" name="add_service" class="btn">           <!-- Submit button -->
   </form>

</section>

<!-- service CRUD section ends -->

<!-- show services  -->

<section class="show-services">

   <div class="box-container">

      <?php
         $select_services = mysqli_query($conn, "SELECT * FROM `services`") or die('query failed');  // Fetches all services from the database
         if(mysqli_num_rows($select_services) > 0){                                                  // Checks if there are services in the database
            while($fetch_services = mysqli_fetch_assoc($select_services)){                           // Loops through each service
      ?>
      <div class="box">
         <img src="uploaded_img/<?php echo $fetch_services['image']; ?>" alt="">         <!-- Displays service image -->
         <div class="name"><?php echo $fetch_services['name']; ?></div>                  <!-- Displays service name -->
         <div class="description"><?php echo $fetch_services['description']; ?></div>  <!-- Show service description -->

         <div class="price">Rs <?php echo $fetch_services['price']; ?>/-</div>             <!-- Displays service price -->
         <a href="admin_services.php?update=<?php echo $fetch_services['id']; ?>" class="option-btn">update</a>    <!-- Update service link -->
         <a href="admin_services.php?delete=<?php echo $fetch_services['id']; ?>" class="delete-btn" onclick="return confirm('delete this service?');">delete</a>  <!-- Delete service link with confirmation -->
      </div>
      <?php
         }
      }else{
         echo '<p class="empty">no services added yet!</p>';  // Displays message if no services exist
      }
      ?>
   </div>

</section>

<section class="edit-service-form">

   <?php
      if(isset($_GET['update'])){                                                             // Checks if 'update' is set in the URL
         $update_id = $_GET['update'];                                                         // Gets the service ID to update            
         $update_query = mysqli_query($conn, "SELECT * FROM `services` WHERE id = '$update_id'") or die('query failed');   // Fetches service details
         if(mysqli_num_rows($update_query) > 0){                                               // Checks if the service exists
            while($fetch_update = mysqli_fetch_assoc($update_query)){                          // Loops through the service data                
   ?>
   <form action="" method="post" enctype="multipart/form-data">                           <!-- Form for updating services -->
      <input type="hidden" name="update_p_id" value="<?php echo $fetch_update['id']; ?>">  <!-- Hidden field to store service ID -->
      <input type="hidden" name="update_old_image" value="<?php echo $fetch_update['image']; ?>">  <!-- Hidden field to store old image name -->
      <img src="uploaded_img/<?php echo $fetch_update['image']; ?>" alt="">                            <!-- Displays current service image -->
      <input type="text" name="update_name" value="<?php echo $fetch_update['name']; ?>" class="box" required placeholder="enter service name">      <!-- Name input for update -->
      <input type="text" name="update_description" value="<?php echo $fetch_update['description']; ?>" class="box" required placeholder="enter service description">  <!-- New description input field -->

      <input type="number" name="update_price" value="<?php echo $fetch_update['price']; ?>" min="0" class="box" required placeholder="enter service price">  <!-- Price input for update -->
      <input type="file" class="box" name="update_image" accept="image/jpg, image/jpeg, image/png">   <!-- File input for new image (optional) -->
      <input type="submit" value="update" name="update_service" class="btn">                           <!-- Update button -->
      <input type="reset" value="cancel" id="close-update" class="option-btn">                         <!-- Cancel button -->
   </form>
   <?php
         }
      }
      }else{
         echo '<script>document.querySelector(".edit-service-form").style.display = "none";</script>';    // Hides the update form if no update is requested
      }
   ?>

</section>


<!-- custom admin js file link  -->
<script src="js/admin_script.js"></script>

</body>
</html>