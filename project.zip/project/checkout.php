<?php

include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}


// Checking if the "Book_btn" (submit button) has been pressed
if(isset($_POST['Book_btn'])){


   // Retrieving the user's inputs from the form and sanitizing the input to avoid SQL injection
   $name = mysqli_real_escape_string($conn, $_POST['name']);
   $number = $_POST['number'];
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $address = mysqli_real_escape_string($conn, 'flat no. '. $_POST['flat'].', '. $_POST['street'].', '. $_POST['city'].', '. $_POST['country'].' - '. $_POST['pin_code']);
   $placed_on = date('d-M-Y');


   $queue_total = 0;

   // Joining all the queue service names into a string for the appointment
   $queue_services = array(); // Initialize as an empty array
$queue_query = mysqli_query($conn, "SELECT * FROM `queue` WHERE user_id = '$user_id'") or die('query failed');
if(mysqli_num_rows($queue_query) > 0){
   while($queue_item = mysqli_fetch_assoc($queue_query)){
      $queue_services[] = $queue_item['name']; // Store service names in the array
      $sub_total = ($queue_item['price']); // Just the price now (no quantity)
      $queue_total += $sub_total;
   }
}

// Joining all the queue service names into a string for the appointment
$total_services = implode(',', $queue_services); // Now it will work because $queue_services is an array




   // Query to check if an appointment with the same details already exists
   $Book_query = mysqli_query($conn, "SELECT * FROM `appointments` WHERE name = '$name' AND number = '$number' AND email = '$email' AND  address = '$address' AND  total_price = '$queue_total'") or die('query failed');


   // Checking if the queue total is 0, if true, sending a message
   if($queue_total == 0){
      $message[] = 'your queue is empty';
   }else{                                                                     // Checking if the same appointment has already been placed
      if(mysqli_num_rows($Book_query) > 0){
         $message[] = 'appointment already placed!'; 
      }else{
         mysqli_query($conn, "INSERT INTO `appointments`(user_id, name, number, email, address, total_services, total_price, placed_on) VALUES('$user_id', '$name', '$number', '$email', '$address', '$total_services', '$queue_total', '$placed_on')") or die('query failed');
         $message[] = 'Appointment booked successfully!';
         
           // Deleting the items from the queue after placing the appointment
           mysqli_query($conn, "DELETE FROM `queue` WHERE user_id = '$user_id'") or die('query failed');
         }
      
      
   }
   
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>checkout</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'header.php'; ?>

<div class="heading">
   <h3>checkout</h3>
   <p> <a href="home.php">home</a> / checkout </p>
</div>

<section class="display-book">

   <?php  
      $grand_total = 0;
      $select_queue = mysqli_query($conn, "SELECT * FROM `queue` WHERE user_id = '$user_id'") or die('query failed');
      if(mysqli_num_rows($select_queue) > 0){                                                       // Looping through each queue item to display the services and calculate the grand total
         while($fetch_queue = mysqli_fetch_assoc($select_queue)){             
            $total_price = $fetch_queue['price']; // Just use the price of each item without multiplying by quantity
            $grand_total += $total_price;
      ?>
   
   <p> <?php echo $fetch_queue['name']; ?> <span>(<?php echo 'Rs '.$fetch_queue['price'].'/-'; ?>)</span> </p>

   <?php
      }
   }else{
      echo '<p class="empty">your queue is empty</p>';                    // If queue is empty, displaying a message
   }
   ?>
   <div class="grand-total"> grand total : <span>Rs <?php echo $grand_total; ?>/-</span> </div>

</section>

<section class="checkout">

   <form action="" method="post">
      <h3>Book your appointment</h3>
      <div class="flex">
         <div class="inputBox">
            <span>Your name :</span>
            <input type="text" name="name" required placeholder="Enter your name">
         </div>
         <div class="inputBox">
            <span>Your number :</span>
            <input type="number" name="number" required placeholder="Enter your number">
         </div>
         <div class="inputBox">
            <span>Your email :</span>
            <input type="email" name="email" required placeholder="Enter your email">
         </div>
         
         <div class="inputBox">
            <span>Address line 01 :</span>
            <input type="number" min="0" name="flat" required placeholder="e.g. flat no.">
         </div>
         <div class="inputBox">
            <span>Address line 02 :</span>
            <input type="text" name="street" required placeholder="e.g. street name">
         </div>
         <div class="inputBox">
            <span>City :</span>
            <input type="text" name="city" required placeholder="e.g. Colombo">
         </div>
         <div class="inputBox">
            <span>State :</span>
            <input type="text" name="state" required placeholder="e.g. Western Province">
         </div>
         <div class="inputBox">
            <span>Postal code :</span>
            <input type="number" min="0" name="pin_code" required placeholder="e.g. 123456">
         </div>
         <div class="inputBox">
            <span>Country :</span>
            <input type="text" name="country" required placeholder="e.g. Sri Lanka">
         </div>
      </div>
      <input type="submit" value="Book appointments" class="btn" name="Book_btn">
   </form>

</section>


<?php include 'footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>