<?php

include 'config.php';

session_start();

$user_id = $_SESSION['user_id'] ?? null;

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>about</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'header.php'; ?>

<div class="heading">
   <h3>about us</h3>
   <p> <a href="home.php">home</a> / about </p>
</div>

<section class="about">

   <div class="flex">

      <div class="image">
         <img src="images/about-img2.jpg" alt="">
      </div>

      <div class="content">
         <h3>why choose us?</h3>
         <p>Care Compass Hospitals offers expert medical care with advanced facilities and a dedicated team of professionals. We ensure personalized treatment across multiple specialties with a patient-first approach.</p>
         <p>With easy online appointments, secure medical records, and 24/7 emergency care, we make healthcare accessible and stress-free. Your health is our priority.</p>
         <a href="contact.php" class="btn">contact us</a>
      </div>

   </div>

</section>

<section class="doctors">

   <h1 class="title">Our Doctors</h1>

   <div class="box-container">

      <div class="box">
         <img src="images/pic-1.jpg" alt="">
         <p>Expert in heart disease treatment, offering advanced care at National Heart Foundation, Colombo.</p>
      
         <h3>Dr. Anura Jayasinghe</h3>
         <h4>Consultant Cardiologist<h4>
      </div>

      <div class="box">
         <img src="images/pic-2.jpg" alt="">
         <p>Specializes in diagnosing and treating neurological disorders at Nawaloka Hospital, Colombo.</p>
      
         <h3>Dr. Nadeesha Wijeratne</h3>
         <h4>Consultant Neurologist<h4>
      </div>

      <div class="box">
         <img src="images/pic-3.jpg" alt="">
         <p>Performs complex surgeries at Asiri Surgical Hospital, Kandy, ensuring effective treatment for various conditions.</p>
         
         <h3>Dr. Tharindu Senanayake</h3>
         <h4>General Surgeon<h4>
      </div>

      <div class="box">
         <img src="images/pic-4.jpg" alt="">
         <p> Provides specialized care for children at Lady Ridgeway Hospital, Colombo, ensuring healthy growth and development.</p>
         
         <h3>Dr. Ishara Ekanayake</h3>
         <h4><h4>Consultant Pediatrician<h4><h4>
      </div>

      <div class="box">
         <img src="images/pic-5.jpg" alt="">
         <p>Expert in treating bone fractures and joint disorders at Lanka Hospital, Colombo, with advanced surgical techniques.</p>
         
         <h3>Dr. Chaminda Rathnayake</h3>
         <h4>Orthopedic Surgeon<h4>
      </div>

      <div class="box">
         <img src="images/pic-6.jpg" alt="">
         <p>Dedicated to women’s health at Base Hospital, Kurunegala, offering expert maternity and gynecological care.</p>
         
         <h3>Dr. Dilini Karunaratne</h3>
         <h4>Consultant Obstetrician & Gynecologist<h4>
      </div>

   </div>

</section>

<section class="staff">

   <h1 class="title">Our Staff</h1>

   <div class="box-container">

      <div class="box">
         <img src="images/staff-1.jpg" alt="">
         <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
            <a href="#" class="fab fa-instagram"></a>
            <a href="#" class="fab fa-linkedin"></a>
         </div>
         <h3>Mr. Dilan Silva</h3>
         <h4>Senior Lab Technician<h4>
      </div>

      <div class="box">
         <img src="images/staff-2.jpg" alt="">
         <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
            <a href="#" class="fab fa-instagram"></a>
            <a href="#" class="fab fa-linkedin"></a>
         </div>
         <h3>Ms. Ruwani Perera</h3>
         <h4>Head Nurse<h4>
      </div>

      <div class="box">
         <img src="images/staff-3.jpg" alt="">
         <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
            <a href="#" class="fab fa-instagram"></a>
            <a href="#" class="fab fa-linkedin"></a>
         </div>
         <h3>Mr. Kasun Jayawardena</h3>
         <h4>Radiology Techniciann<h4>
      </div>

      <div class="box">
         <img src="images/staff-4.jpg" alt="">
         <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
            <a href="#" class="fab fa-instagram"></a>
            <a href="#" class="fab fa-linkedin"></a>
         </div>
         <h3>Ms. Thilini Fernando</h3>
         <h4>Pharmacy Manager<h4>
      </div>

      <div class="box">
         <img src="images/staff-5.jpg" alt="">
         <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
            <a href="#" class="fab fa-instagram"></a>
            <a href="#" class="fab fa-linkedin"></a>
         </div>
         <h3>Mr. Pradeep Ranasinghe</h3>
         <h4>IT & Systems Administrator<h4>
      </div>

      <div class="box">
         <img src="images/staff-6.jpg" alt="">
         <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
            <a href="#" class="fab fa-instagram"></a>
            <a href="#" class="fab fa-linkedin"></a>
         </div>
         <h3>Ms. Sanduni Wickramasinghe</h3>
         <h4>Patient Relations Officer</h4>
      </div>

   </div>

</section>







<?php include 'footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>