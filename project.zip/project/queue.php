<?php

include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}




// Handle individual item deletion

if(isset($_GET['delete'])){
   $delete_id = $_GET['delete'];     // Get queue item ID
   mysqli_query($conn, "DELETE FROM `queue` WHERE id = '$delete_id'") or die('query failed');  // Delete the item from the database
   header('location:queue.php');                  // Refresh queue page
}


// Handle clearing the entire queue

if(isset($_GET['delete_all'])){
   mysqli_query($conn, "DELETE FROM `queue` WHERE user_id = '$user_id'") or die('query failed');    // Delete all items belonging to the current user
   header('location:queue.php');           // Refresh queue page
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>queue</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'header.php'; ?>

<div class="heading">
   <h3>Queue</h3>
   <p> <a href="home.php">home</a> / queue </p>
</div>

<section class="services-queue">

   <h1 class="title">services added</h1>

   <div class="box-container">
      <?php
         $grand_total = 0;          // Initialize grand total
         $select_queue = mysqli_query($conn, "SELECT * FROM `queue` WHERE user_id = '$user_id'") or die('query failed');  // Fetch queue items for the logged-in user
         if(mysqli_num_rows($select_queue) > 0){ 
            while($fetch_queue = mysqli_fetch_assoc($select_queue)){   
      ?>
      <div class="box">
         <a href="queue.php?delete=<?php echo $fetch_queue['id']; ?>" class="fas fa-times" onclick="return confirm('delete this from queue?');"></a>   <!-- Delete item button -->
         <img src="uploaded_img/<?php echo $fetch_queue['image']; ?>" alt="">                                                                        <!-- service image -->
         <div class="name"><?php echo $fetch_queue['name']; ?></div>                                                                                 <!-- service name -->
         <div class="description"><?php echo $fetch_queue['description']; ?></div>
         <div class="price">Rs <?php echo $fetch_queue['price']; ?>/-</div>                                                                            <!-- service price -->
        
         
      </div>
      <?php
      $grand_total += $fetch_queue['price'];
         }
      }else{
         echo '<p class="empty">your queue is empty</p>';
      }
      ?>
   </div>


   <!-- Delete all items button -->

   <div style="margin-top: 2rem; text-align:center;">
      <a href="queue.php?delete_all" class="delete-btn <?php echo ($grand_total > 1)?'':'disabled'; ?>" onclick="return confirm('delete all from queue?');">delete all</a>
   </div>

   <div class="cart-total">
      <p>Total Fee : <span>Rs <?php echo $grand_total; ?>/-</span></p>
      <div class="flex">
         <a href="services.php" class="option-btn">Back to Services</a>
         <a href="checkout.php" class="btn <?php echo ($grand_total > 0)?'':'disabled'; ?>">proceed to checkout</a>
      </div>
   </div>

</section>



<?php include 'footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>